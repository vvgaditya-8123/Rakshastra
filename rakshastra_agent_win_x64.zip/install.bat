@echo off
title Rakshastra Cyber Defense Agent Installation Wizard
echo ==========================================================
echo   Rakshastra Agent - Windows Installation Wizard
echo ==========================================================
echo.
echo This wizard will set up Python, Node.js, and all required
echo dependencies to run the Rakshastra Agent locally.
echo.
echo Press any key to begin setup...
pause > nul

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
if %errorlevel% neq 0 (
    echo.
    echo [ERROR] Installation failed.
    echo Please review the errors above.
    pause
    exit /b %errorlevel%
)

echo.
echo [SUCCESS] Installation completed successfully!
pause
